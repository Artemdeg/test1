﻿namespace ConsoleAppC3_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("C3.5:");
            Console.Write("Введите количество сотрудников: ");
            int numEmployees = int.Parse(Console.ReadLine());
            double[] salaries = new double[numEmployees];
            double totalSalaries = 0;

            Console.WriteLine("Введите зарплату каждого сотрудника:");
            for (int i = 0; i < numEmployees; i++)
            {
                Console.Write($"Зарплата сотрудника {i + 1}: ");
                salaries[i] = double.Parse(Console.ReadLine());
                totalSalaries += salaries[i];
            }
            Console.WriteLine($"Общая сумма выплаченных по ведомости денег: {totalSalaries}\n");
        }
    }
}
