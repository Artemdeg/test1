﻿namespace ConsoleAppC1_4
{
    using System;

    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("C1.4 а):");
            for (int i = 10; i <= 25; i++)
            {
                Console.WriteLine($"{i} {i + 0.4}"); // Используем интерполяцию строк для форматирования
            }
            Console.WriteLine("\n");

            // C1.4 б)
            Console.WriteLine("C1.4 б):");
            for (int i = 25; i <= 35; i++)
            {
                Console.WriteLine($"{i} {i + 0.5} {i + 0.5 - 0.7}"); // Используем интерполяцию строк для форматирования
            }
            Console.WriteLine("\n");
        }
    }
}