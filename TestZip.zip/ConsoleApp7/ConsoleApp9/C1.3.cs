﻿namespace ConsoleAppC1_3
{
    using System;

    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("C1.3 а):");
            for (int i = 20; i <= 35; i++)
            {
                Console.WriteLine(i);
            }
            Console.WriteLine("\n");

            // C1.3 б)
            Console.WriteLine("C1.3 б):");
            Console.Write("Введите b (b > 10): ");
            int b = int.Parse(Console.ReadLine());

            if (b > 10)
            {
                for (int i = 10; i <= b; i++)
                {
                    Console.WriteLine(i * i);
                }
            }
            else
            {
                Console.WriteLine("Ошибка: b должно быть больше 10.");
            }
            Console.WriteLine("\n");

            // C1.3 в)
            Console.WriteLine("C1.3 в):");
            Console.Write("Введите a (a < 50): ");
            int a = int.Parse(Console.ReadLine());

            if (a < 50)
            {
                for (int i = a; i <= 50; i++)
                {
                    Console.WriteLine(Math.Pow(i, 3));
                }
            }
            else
            {
                Console.WriteLine("Ошибка: a должно быть меньше 50.");
            }
            Console.WriteLine("\n");

            // C1.3 г)
            Console.WriteLine("C1.3 г):");
            Console.Write("Введите a: ");
            int a_g = int.Parse(Console.ReadLine());
            Console.Write("Введите b (b < a): ");
            int b_g = int.Parse(Console.ReadLine());

            if (b_g < a_g)
            {
                for (int i = a_g; i >= b_g; i--)
                {
                    Console.WriteLine(i);
                }
            }
            else
            {
                Console.WriteLine("Ошибка: b должно быть меньше a.");
            }
            Console.WriteLine("\n");

        }
    }
}