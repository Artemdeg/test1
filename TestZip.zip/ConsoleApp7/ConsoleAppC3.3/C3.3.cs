﻿namespace ConsoleAppC3_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // C3.3
            Console.WriteLine("C3.3:");
            double[] masses = new double[12];
            double totalMass = 0;

            Console.WriteLine("Введите массу каждого из 12 предметов:");
            for (int i = 0; i < 12; i++)
            {
                Console.Write($"Масса предмета {i + 1}: ");
                masses[i] = double.Parse(Console.ReadLine());
                totalMass += masses[i];
            }
            Console.WriteLine($"Общая масса набора предметов: {totalMass}\n");
        }
    }
}
