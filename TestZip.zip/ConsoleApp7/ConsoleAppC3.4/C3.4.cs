﻿namespace ConsoleAppC3_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("C3.4:");
            double[] grades = new double[4];
            double totalScore = 0;

            Console.WriteLine("Введите оценки абитуриента на четырех экзаменах:");
            for (int i = 0; i < 4; i++)
            {
                Console.Write($"Оценка за экзамен {i + 1}: ");
                grades[i] = double.Parse(Console.ReadLine());
                totalScore += grades[i];
            }
            Console.WriteLine($"Сумма набранных баллов: {totalScore}\n");
        }
    }
}
