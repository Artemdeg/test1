﻿namespace ConsoleAppC2._5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // C2.5
            Console.WriteLine("C2.5:");
            Console.Write("Введите натуральное число n: ");
            int n5 = int.Parse(Console.ReadLine());
            double sum5 = 0; // Use double for larger values after squaring
            for (int i = n5; i <= 2 * n5; i++)
            {
                sum5 += Math.Pow(i, 2);
            }
            Console.WriteLine($"Сумма n^2 + (n+1)^2 + ... + (2n)^2 для n = {n5}: {sum5}\n");
        }
    }
}
