﻿namespace ConsoleAppC2._4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // C2.4 a)
            Console.WriteLine("C2.4 a):");
            double sum_a4 = 0; 
            for (int i = 20; i <= 40; i++)
            {
                sum_a4 += Math.Pow(i, 3);
            }
            Console.WriteLine($"Сумма кубов чисел от 20 до 40: {sum_a4}\n");

            // C2.4 b)
            Console.WriteLine("C2.4 b):");
            Console.Write("Введите a (0 < a <= 50): ");
            int a_b4 = int.Parse(Console.ReadLine());
            if (a_b4 > 0 && a_b4 <= 50)
            {
                double sum_b4 = 0; 
                for (int i = a_b4; i <= 50; i++)
                {
                    sum_b4 += Math.Pow(i, 2);
                }
                Console.WriteLine($"Сумма квадратов чисел от {a_b4} до 50: {sum_b4}\n");
            }
            else
            {
                Console.WriteLine("Ошибка: a должно быть в диапазоне от 1 до 50.\n");
            }

            // C2.4 c)
            Console.WriteLine("C2.4 c):");
            Console.Write("Введите n (1 <= n <= 100): ");
            int n_c4 = int.Parse(Console.ReadLine());
            if (n_c4 >= 1 && n_c4 <= 100)
            {
                double sum_c4 = 0; 
                for (int i = 1; i <= n_c4; i++)
                {
                    sum_c4 += Math.Pow(i, 2);
                }
                Console.WriteLine($"Сумма квадратов чисел от 1 до {n_c4}: {sum_c4}\n");
            }
            else
            {
                Console.WriteLine("Ошибка: n должно быть в диапазоне от 1 до 100.\n");
            }

            // C2.4 d)
            Console.WriteLine("C2.4 d):");
            Console.Write("Введите a: ");
            int a_d4 = int.Parse(Console.ReadLine());
            Console.Write("Введите b (b > a): ");
            int b_d4 = int.Parse(Console.ReadLine());
            if (b_d4 > a_d4)
            {
                double sum_d4 = 0; 
                for (int i = a_d4; i <= b_d4; i++)
                {
                    sum_d4 += Math.Pow(i, 2);
                }
                Console.WriteLine($"Сумма квадратов чисел от {a_d4} до {b_d4}: {sum_d4}\n");
            }
            else
            {
                Console.WriteLine("Ошибка: b должно быть больше a.\n");
            }
        }
    }
}
