﻿namespace ConsoleAppC3_1
{
    using System;

    public class Program
    {
        public static void Main(string[] args)
        {
            // C3.1
            Console.WriteLine("C3.1:");
            double[] a1_a10 = { 1.1, 2.2, 3.3, 4.4, 5.5, 6.6, 7.7, 8.8, 9.9, 10.1 }; // Пример данных
            double sum1 = 0;
            for (int i = 0; i < a1_a10.Length; i++)
            {
                sum1 += a1_a10[i];
            }
            Console.WriteLine($"Сумма чисел: {sum1}\n");
        }
    }
}

