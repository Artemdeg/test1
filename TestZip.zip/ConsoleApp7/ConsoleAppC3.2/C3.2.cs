﻿namespace ConsoleAppC3_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // C3.2
            Console.WriteLine("C3.2:");
            Console.Write("Введите количество чисел n: ");
            int n = int.Parse(Console.ReadLine());
            double[] a = new double[n];
            double sum2 = 0;

            Console.WriteLine($"Введите {n} вещественных чисел:");
            for (int i = 0; i < n; i++)
            {
                Console.Write($"Число {i + 1}: ");
                a[i] = double.Parse(Console.ReadLine());
                sum2 += a[i];
            }
            Console.WriteLine($"Сумма вещественных чисел: {sum2}\n");
        }
    }
}
