﻿namespace ConsoleAppC1_5
{
    using System;

    public class Program
    {
        public static void Main(string[] args)
        {
            // C1.5 а)
            Console.WriteLine("C1.5 а):");
            for (int i = 21; i >= 10; i--)
            {
                Console.WriteLine($"{i} {i - 1.8}"); // Используем интерполяцию строк для форматирования
            }
            Console.WriteLine("\n");

            // C1.5 б)
            Console.WriteLine("C1.5 б):");
            for (int i = 45; i >= 25; i--)
            {
                Console.WriteLine($"{i} {i - 0.5} {i - 0.8}"); // Используем интерполяцию строк для форматирования
            }
            Console.WriteLine("\n");
        }
    }
}
