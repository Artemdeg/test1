﻿namespace ConsoleAppC1_1
{
    using System;

    public class Program
    {
        public static void Main(string[] args)
        {
            // C1.1
            Console.WriteLine("C1.1:");
            for (int i = 0; i < 10; i++)
            {
                Console.Write("20 ");
            }
            Console.WriteLine("\n");
        }
    }
}
