﻿namespace ConsoleAppC2_1
{
    using System;

    public class Program
    {
        public static void Main(string[] args)
        {
            // C2.1 a)
            Console.WriteLine("C2.1 a):");
            int sum_a = 0;
            for (int i = 100; i <= 500; i++)
            {
                sum_a += i;
            }
            Console.WriteLine($"Сумма чисел от 100 до 500: {sum_a}\n");

            // C2.1 b)
            Console.WriteLine("C2.1 b):");
            Console.Write("Введите a (a < 500): ");
            int a_b = int.Parse(Console.ReadLine());
            if (a_b < 500)
            {
                int sum_b = 0;
                for (int i = a_b; i <= 500; i++)
                {
                    sum_b += i;
                }
                Console.WriteLine($"Сумма чисел от {a_b} до 500: {sum_b}\n");
            }
            else
            {
                Console.WriteLine("Ошибка: a должно быть меньше 500.\n");
            }

            // C2.1 c)
            Console.WriteLine("C2.1 c):");
            Console.Write("Введите b (b > -10): ");
            int b_c = int.Parse(Console.ReadLine());
            if (b_c > -10)
            {
                int sum_c = 0;
                for (int i = -10; i <= b_c; i++)
                {
                    sum_c += i;
                }
                Console.WriteLine($"Сумма чисел от -10 до {b_c}: {sum_c}\n");
            }
            else
            {
                Console.WriteLine("Ошибка: b должно быть больше -10.\n");
            }

            // C2.1 d)
            Console.WriteLine("C2.1 d):");
            Console.Write("Введите a: ");
            int a_d = int.Parse(Console.ReadLine());
            Console.Write("Введите b (b > a): ");
            int b_d = int.Parse(Console.ReadLine());
            if (b_d > a_d)
            {
                int sum_d = 0;
                for (int i = a_d; i <= b_d; i++)
                {
                    sum_d += i;
                }
                Console.WriteLine($"Сумма чисел от {a_d} до {b_d}: {sum_d}\n");
            }
            else
            {
                Console.WriteLine("Ошибка: b должно быть больше a.\n");
            }
        }
    }
}