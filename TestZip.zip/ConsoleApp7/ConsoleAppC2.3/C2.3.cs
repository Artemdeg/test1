﻿namespace ConsoleAppC2._3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // C2.3 a)
            Console.WriteLine("C2.3 a):");
            double sum_a3 = 0;
            for (int i = 1; i <= 1000; i++)
            {
                sum_a3 += i;
            }
            double avg_a3 = sum_a3 / 1000;
            Console.WriteLine($"Среднее арифметическое чисел от 1 до 1000: {avg_a3}\n");

            // C2.3 b)
            Console.WriteLine("C2.3 b):");
            Console.Write("Введите b (b > 100): ");
            int b_b3 = int.Parse(Console.ReadLine());
            if (b_b3 > 100)
            {
                double sum_b3 = 0;
                for (int i = 100; i <= b_b3; i++)
                {
                    sum_b3 += i;
                }
                double avg_b3 = sum_b3 / (b_b3 - 100 + 1);
                Console.WriteLine($"Среднее арифметическое чисел от 100 до {b_b3}: {avg_b3}\n");
            }
            else
            {
                Console.WriteLine("Ошибка: b должно быть больше 100.\n");
            }

            // C2.3 c)
            Console.WriteLine("C2.3 c):");
            Console.Write("Введите a (a < 200): ");
            int a_c3 = int.Parse(Console.ReadLine());
            if (a_c3 < 200)
            {
                double sum_c3 = 0;
                for (int i = a_c3; i <= 200; i++)
                {
                    sum_c3 += i;
                }
                double avg_c3 = sum_c3 / (200 - a_c3 + 1);
                Console.WriteLine($"Среднее арифметическое чисел от {a_c3} до 200: {avg_c3}\n");
            }
            else
            {
                Console.WriteLine("Ошибка: a должно быть меньше 200.\n");
            }

            // C2.3 d)
            Console.WriteLine("C2.3 d):");
            Console.Write("Введите a: ");
            int a_d3 = int.Parse(Console.ReadLine());
            Console.Write("Введите b (b > a): ");
            int b_d3 = int.Parse(Console.ReadLine());
            if (b_d3 > a_d3)
            {
                double sum_d3 = 0;
                for (int i = a_d3; i <= b_d3; i++)
                {
                    sum_d3 += i;
                }
                double avg_d3 = sum_d3 / (b_d3 - a_d3 + 1);
                Console.WriteLine($"Среднее арифметическое чисел от {a_d3} до {b_d3}: {avg_d3}\n");
            }
            else
            {
                Console.WriteLine("Ошибка: b должно быть больше a.\n");
            }
        }
    }
}
