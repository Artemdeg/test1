﻿namespace ConsoleAppC2_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // C2.2 a)
            Console.WriteLine("C2.2 a):");
            long product_a = 1;
            for (int i = 8; i <= 15; i++)
            {
                product_a *= i;
            }
            Console.WriteLine($"Произведение чисел от 8 до 15: {product_a}\n");

            // C2.2 b)
            Console.WriteLine("C2.2 b):");
            Console.Write("Введите a (1 <= a <= 20): ");
            int a_b2 = int.Parse(Console.ReadLine());
            if (a_b2 >= 1 && a_b2 <= 20)
            {
                long product_b = 1;
                for (int i = a_b2; i <= 20; i++)
                {
                    product_b *= i;
                }
                Console.WriteLine($"Произведение чисел от {a_b2} до 20: {product_b}\n");
            }
            else
            {
                Console.WriteLine("Ошибка: a должно быть в диапазоне от 1 до 20.\n");
            }

            // C2.2 c)
            Console.WriteLine("C2.2 c):");
            Console.Write("Введите b (1 <= b <= 20): ");
            int b_c2 = int.Parse(Console.ReadLine());
            if (b_c2 >= 1 && b_c2 <= 20)
            {
                long product_c = 1;
                for (int i = 1; i <= b_c2; i++)
                {
                    product_c *= i;
                }
                Console.WriteLine($"Произведение чисел от 1 до {b_c2}: {product_c}\n");
            }
            else
            {
                Console.WriteLine("Ошибка: b должно быть в диапазоне от 1 до 20.\n");
            }

            // C2.2 d)
            Console.WriteLine("C2.2 d):");
            Console.Write("Введите a: ");
            int a_d2 = int.Parse(Console.ReadLine());
            Console.Write("Введите b (b > a): ");
            int b_d2 = int.Parse(Console.ReadLine());
            if (b_d2 > a_d2)
            {
                long product_d = 1;
                for (int i = a_d2; i <= b_d2; i++)
                {
                    product_d *= i;
                }
                Console.WriteLine($"Произведение чисел от {a_d2} до {b_d2}: {product_d}\n");
            }
            else
            {
                Console.WriteLine("Ошибка: b должно быть больше a.\n");
            }
        }
    }
}
