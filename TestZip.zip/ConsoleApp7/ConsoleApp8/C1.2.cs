﻿namespace ConsoleAppC1_2
{
    using System;

    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("C1.2:");
            Console.Write("Введите число: ");
            int number = int.Parse(Console.ReadLine());
            Console.Write("Введите количество повторений: ");
            int count = int.Parse(Console.ReadLine());

            for (int i = 0; i < count; i++)
            {
                Console.Write(number + " ");
            }
            Console.WriteLine("\n");

        }
    }
}